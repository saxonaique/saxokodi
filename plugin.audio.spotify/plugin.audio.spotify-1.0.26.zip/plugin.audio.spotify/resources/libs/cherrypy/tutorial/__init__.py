
# This is used in test_config to test unrepr of "from A import B"
thing2 = object()
