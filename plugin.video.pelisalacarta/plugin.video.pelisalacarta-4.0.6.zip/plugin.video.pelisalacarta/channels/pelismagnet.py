# -*- coding: utf-8 -*-
#------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para elitetorrent
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
#------------------------------------------------------------
import urlparse,urllib2,urllib,re
import os, sys

from core import logger
from core import config
from core import scrapertools
from core.item import Item
from servers import servertools

try:
    import json
except:
    logger.info("SERIESLY.py: No se ha podido cargar JSON")
    try:
        import simplejson as json
    except:
        try:
            logger.info("SERIESLY.py: No se ha podido cargar simpleJSON")
            from lib import simplejson as json
        except:
            logger.error("No se ha podido cargar ninguna librería JSON")

__channel__ = "pelismagnet"
__category__ = "F,S,D"
__type__ = "generic"
__title__ = "Pelis Magnet"
__language__ = "ES"

DEBUG = config.get_setting("debug")
BASE_URL = 'http://pelismag.net'

def isGeneric():
    return True

def mainlist(item):

    itemlist = []
    itemlist.append( Item(channel=__channel__, action="estrenos" , title="Estrenos"))
    itemlist.append( Item(channel=__channel__, title="+ Populares"     , action="peliculas", url="http://pelismag.net/api"))
    itemlist.append( Item(channel=__channel__, action="populares" , title="+ Valoradas"))
    itemlist.append( Item(channel=__channel__, action="search" , title="Buscar..."))
    return itemlist

def load_json(data):
    # callback to transform json string values to utf8
    def to_utf8(dct):
        
        rdct = {}
        for k, v in dct.items() :
            

            if isinstance(v, (str, unicode)) :
                rdct[k] = v.encode('utf8', 'ignore')
            else :
                rdct[k] = v

        return rdct

    try:
        json_data = json.loads(data, object_hook=to_utf8)
        
    except:
        try:
            logger.info("core.jsontools.load_json Probando JSON de Plex")
            json_data = JSON.ObjectFromString(data, encoding="utf-8")
            logger.info("core.jsontools.load_json -> "+repr(json_data))
            
        except:
            logger.info("Problemas cargando JSON")
    return json_data


def obtenirpelis(url):
	itemlist = []
	data = scrapertools.cachePage(url)
	List = load_json(data)
	
	for i in List:
		title = i['nom']
		try:
			if i['magnets']['M1080']['magnet'] != None:
				url = i['magnets']['M1080']['magnet']
			else:
				url = i['magnets']['M720']['magnet']  
		except:
			try:
				url = i['magnets']['M720']['magnet']  
			except:
				error_message('No hay enlace magnet disponible para esta pelicula')
				return []  
		try:
			thumbnail = 'http://image.tmdb.org/t/p/w342' + i['posterurl']
		except:
			thumbnail = 'No disponible'
		plot = i['info']
		itemlist.append( Item(channel=__channel__, action="play", title=title , url=url , thumbnail=thumbnail , plot=plot , folder=False, viewmode="movie_with_plot") )
	return itemlist


def peliculas(item):

    return obtenirpelis(item.url)


def search(item,texto):
	url = 'http://pelismag.net/api?keywords=' + texto.replace(' ','%20')

	return obtenirpelis(url)

def estrenos(item):
	url = 'http://pelismag.net/api?sort_by=date_added'
	return obtenirpelis(url)

def populares(item):
	url = 'http://pelismag.net/api?sort_by=rating'
	return obtenirpelis(url)

def play(item):
    itemlist = []

    itemlist.append( Item(channel=__channel__, action="play", server="torrent", title=item.title , url=item.url , thumbnail=item.thumbnail , plot=item.plot , folder=False) )

    return itemlist
